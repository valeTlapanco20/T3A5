package t3a5;

public class Cuenta {
  
  private String numeroCuenta; 
  int pin;
  float saldo;    
 
  public Cuenta(){}

    public Cuenta(String numeroCuenta, int pin, float saldo) {
        this.numeroCuenta = numeroCuenta;
        this.pin = pin;
        this.saldo = saldo;
    }
    
    public void consultarSaldo(){
        saldo = 850;
        System.out.println("Tienes un saldo de: " + getSaldo());
    }
    
    public void estadoDeCuenta(){
        System.out.println("Estado de cuenta \n\n"
                + "Cuenta:" + getNumeroCuenta() 
                + "\nSaldo:  " + getSaldo()
                + "\n\n Últimos movimientos: ");
    }
    
    public void retirarEfectivo(){
        if (getSaldo() >=0) {
            System.out.println("¿Cuánto desea retirar?");
    } else { 
    System.out.println("No hay dinero :("
    + "\nFondos Insuficientes");
    }
}
    
public void seguros (){
    System.out.println("Seguros"
            + "\n1.Seguro para tu auto"
            + "\n2.Seguro de vida"
            + "\n3.Seguro medico"
            + "\n4.Seguro de vivienda");
}   

public void creditos(){
    System.out.println("Créditos"
            + "\n1.Hipotecario"
            + "\n2.Crediauto"
            + "\n3.Familiar"
            + "\n4.Personal");
}

public void salir (){
    System.out.println("Gracias :D, que tenga un lindo d");
}
    @Override
  public String toString(){
      String mensaje = "Numero de cuenta: " + numeroCuenta;
      return mensaje;
  }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
  
}